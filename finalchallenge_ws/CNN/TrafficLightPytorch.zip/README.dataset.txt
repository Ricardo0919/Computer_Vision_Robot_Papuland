# Traffic Light Papuland > 2025-05-25 5:28pm
https://universe.roboflow.com/papuland/traffic-light-papuland

Provided by a Roboflow user
License: CC BY 4.0

