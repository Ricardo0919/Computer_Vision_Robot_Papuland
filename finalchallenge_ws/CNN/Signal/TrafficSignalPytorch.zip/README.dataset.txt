# Traffic Signal > 2025-06-03 12:51pm
https://universe.roboflow.com/papuland-traffic-signal-hxr6x/traffic-signal-tocqv

Provided by a Roboflow user
License: CC BY 4.0

